Name: Nahor Yirgaalem(type your name here)
ID: 190775540
Email: yirg5540@mylaurier.ca
WorkID: cp411-a4
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: Q -- Question, T -- Lab tasks
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid: [self-evaluation/total/marker-evaluation]

A4

Q1 Culling, Lighting, Shading

Q1.1 Concepts of culling                  [5/5/*]
Q1.2 Culling computing                    [5/5/*]
Q1.3 Concepts of lighting and shading     [5/5/*]
Q1.4 Lighting computing                   [5/5/*]

Q2 OpenGL culling, lighting, shading

Q2.1 Hidden surface removal               [5/5/*]
Q2.2 Lighting and Shading                 [5/5/*]

Q3 SimpleView2 - culling, lighting, shading

Q3.1 Culling                              [20/20/*]
Q3.2 Lighting                             [15/15/*]
Q3.3 Shading                              [20/20/*]
Q3.4 Animations                           [15/15/*]

Total:                                    [100/100/*]