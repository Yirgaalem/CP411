Name: Nahor Yirgaalem(type your name here)
ID: 190775540	
Email: yirg5540@mylaurier.ca
WorkID: cp411-a1
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: Q -- Question, T -- Lab tasks
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid: [self-evaluation/total/marker-evaluation]

A1

Q1 Concepts of raster graphics

Q1.1 frame buffer                         [2/2/*]
Q1.2 pixel                                [2/2/*]
Q1.3 color depth                          [2/2/*]
Q1.4 resolution                           [2/2/*]

Q2 Concepts of raster display

Q2.1 scan line                            [2/2/*]
Q2.2 refreshment & refresh rate           [2/2/*]
Q2.3 frame                                [2/2/*]

Q3 Roles of CPU and GPU in CG

Q3.1 CPU roles                            [3/3/*]
Q3.2 GPU roles                            [3/3/*]

Q4 C/C++ OpenGL programming environment

Q4.1 C/C++ OpenGL installation            [4/4/*]
Q4.2 OpenGL C project                     [3/3/*]
Q4.3 OpenGL C++ project                   [3/3/*]

Total:                                    [30/30/*]